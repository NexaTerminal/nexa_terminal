import React from 'react';
import BaseDocumentPage from '../../../../components/documents/BaseDocumentPage';
import FormField, { ConditionalField } from '../../../../components/forms/FormField';
import { saasAgreementConfig, getStepFields } from '../../../../config/documents/saasAgreement';
import styles from '../../../../styles/terminal/documents/DocumentGeneration.module.css';

/**
 * SaaS Agreement Page
 * Uses the reusable base components and configuration-driven approach
 * This page generates professional Software as a Service agreements in Macedonian
 */
const SaasAgreementPage = () => {

  // Dynamic placeholder examples for service description based on selected service
  const getServiceDescriptionPlaceholder = (serviceName) => {
    const placeholders = {
      'CRM Платформа': 'Облачен систем за управување со односи со клиенти кој вклучува модули за продажба, маркетинг, поддршка на клиенти, автоматизација на процеси и детални извештаи за перформанси.',
      'ERP Систем': 'Интегриран облачен систем за планирање на деловни ресурси со модули за финансии, сметководство, набавки, продажби, управување со залихи, човечки ресурси и проектно менаџирање.',
      'Систем за управување со проекти': 'Платформа за планирање, следење и управување со проекти која вклучува Gantt графици, task management, тимска соработка, time tracking и извештаи за напредок.',
      'Платформа за e-Commerce': 'Комплетна онлајн продавница со систем за управување со производи, процесирање на нарачки, интеграција со платни системи, управување со залихи и маркетинг алатки.',
      'Систем за управување со документи': 'Облачна платформа за чување, организирање, верзионирање и споделување на деловни документи со напредна претрага, контрола на пристап и автоматизација на работни процеси.',
      'HR Софтвер': 'Систем за управување со човечки ресурси кој вклучува евиденција на вработени, пријави/одјави, годишни одмори, плати, перформанси, регрутација и обуки.',
      'Сметководствен софтвер': 'Облачен сметководствен систем со модули за книговодство, фактурирање, извештаи, ДДВ евиденција, банкарско усогласување и финансиски анализи согласно македонските сметководствени стандарди.',
      'Маркетинг автоматизација': 'Платформа за автоматизација на маркетинг активности вклучувајќи email кампањи, lead nurturing, scoring, социјални медиуми, аналитика и интеграција со CRM системи.',
      'Софтвер за поддршка на клиенти': 'Help Desk систем за управување со барања, тикет систем, knowledge base, live chat, автоматизација на одговори и извештаи за задоволство на клиентите.',
      'Систем за email маркетинг': 'Платформа за креирање, испраќање и следење на email кампањи со напредни сегментации, A/B тестирање, автоматизирани секвенци и детални извештаи за отвореност и кликови.',
      'Платформа за онлајн обука': 'LMS (Learning Management System) за креирање и дистрибуција на онлајн курсеви, следење на напредок, сертификати, квизови, видео содржини и интерактивни материјали.',
      'Систем за управување со залихи': 'Облачен систем за следење на залихи во реално време, автоматизација на нарачки, баркод скенирање, мултилокациски инвентар и интеграција со e-commerce и сметководствени системи.',
      'Друго': 'Опишете ја софтверската услуга која ја нудите или користите - вклучете главни модули, функционалности и технички карактеристики.'
    };

    return placeholders[serviceName] || 'Опишете ја SaaS услугата со детален опис на функционалностите, модулите и можностите што ги нуди.';
  };

  /**
   * Custom step content renderer
   * This is the only document-specific logic needed
   */
  const renderStepContent = ({ currentStep, formData, handleInputChange, errors, isGenerating }) => {
    const stepFields = getStepFields(currentStep);
    const stepConfig = saasAgreementConfig.steps.find(s => s.id === currentStep);

    // Map fields with dynamic placeholder for serviceDescription
    const mappedFields = stepFields.map(field => {
      if (field.name === 'serviceDescription') {
        return {
          ...field,
          placeholder: getServiceDescriptionPlaceholder(formData.serviceName)
        };
      }
      return field;
    });

    return (
      <div className={styles['form-section']}>
        <h3>{stepConfig.title}</h3>
        {stepConfig.description && <p>{stepConfig.description}</p>}

        {/* Add informational note for step 1 */}
        {currentStep === 1 && (
          <div className={styles['info-box']} style={{
            backgroundColor: '#e3f2fd',
            border: '1px solid #90caf9',
            borderRadius: '6px',
            padding: '12px',
            marginBottom: '20px',
            fontSize: '14px'
          }}>
            <strong>📋 Информации за SaaS договорот:</strong>
            <ul style={{ margin: '8px 0', paddingLeft: '20px' }}>
              <li>SaaS договорот регулира користење на софтверска услуга преку интернет</li>
              <li>Договорот ги дефинира правата и обврските на давателот и клиентот</li>
              <li>Важно е прецизно да се дефинираат нивоата на услуга (SLA) и техничката поддршка</li>
            </ul>
          </div>
        )}

        {/* Add informational note for step 5 */}
        {currentStep === 5 && (
          <div className={styles['info-box']} style={{
            backgroundColor: '#f8d7da',
            border: '1px solid #f5c6cb',
            borderRadius: '6px',
            padding: '12px',
            marginBottom: '20px',
            fontSize: '14px'
          }}>
            <strong>⚙️ Нивоа на услуга (SLA):</strong>
            <ul style={{ margin: '8px 0', paddingLeft: '20px' }}>
              <li>Системската достапност од 98% е индустриски стандард за SaaS услуги</li>
              <li>Отказниот рок од 30 дена е вообичаена практика за флексибилност</li>
              <li>Дефинирајте јасни услови за поддршка и одржување на системот</li>
            </ul>
          </div>
        )}

        {mappedFields.map(field => (
          <React.Fragment key={field.name}>
            {/* Regular fields */}
            {!field.condition && (
              <FormField
                field={field}
                value={formData[field.name]}
                onChange={handleInputChange}
                error={errors[field.name]}
                disabled={isGenerating}
                formData={formData}
              />
            )}

            {/* Conditional fields */}
            {field.condition && (
              <ConditionalField condition={field.condition} formData={formData}>
                <FormField
                  field={field}
                  value={formData[field.name]}
                  onChange={handleInputChange}
                  error={errors[field.name]}
                  disabled={isGenerating}
                  formData={formData}
                />
              </ConditionalField>
            )}
          </React.Fragment>
        ))}
      </div>
    );
  };

  return (
    <BaseDocumentPage
      config={saasAgreementConfig}
      renderStepContent={renderStepContent}
      title="Договор за софтвер како услуга (SaaS Agreement)"
      description="Пополнете ги потребните податоци за генерирање професионален договор за обезбедување или користење на софтверска услуга преку интернет"
    />
  );
};

export default SaasAgreementPage;
