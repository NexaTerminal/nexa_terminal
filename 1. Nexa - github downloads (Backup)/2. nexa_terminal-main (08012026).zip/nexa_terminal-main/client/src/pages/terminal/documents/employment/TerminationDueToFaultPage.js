import React from 'react';
import BaseDocumentPage from '../../../../components/documents/BaseDocumentPage';
import FormField from '../../../../components/forms/FormField';
import terminationDueToFaultConfig, { ALL_ARTICLE_CASES, ARTICLE_81_CASES, ARTICLE_82_CASES } from '../../../../config/documents/terminationDueToFault';
import styles from '../../../../styles/terminal/documents/DocumentGeneration.module.css';

/**
 * Termination Due to Fault by Employee Page
 * Simplified legal document generation based on Articles 81 and 82 of Macedonia Labor Law
 * Only requires article selection and optional factual situation description
 * All inputs are optional - allows generating empty document for manual completion
 */

const TerminationDueToFaultPage = () => {
  // Dynamic placeholder examples for each article case
  const getFactualSituationPlaceholder = (articleCase) => {
    const placeholders = {
      'article_81_case_1': 'Пример: На ден 15.03.2024, работникот се појави на работа со доцнење од 2 часа без претходно известување и оправдување. Истиот не постапи согласно со интерниот правилник за работно време кој налага навремено информирање на претпоставениот.',
      'article_81_case_2': 'Пример: На ден 20.04.2024, работникот не ги завршил доверените работни задачи во предвидениот рок, иако имал доволно време и ресурси. Задачите беа доставени со доцнење од 5 дена што предизвика застој во работниот процес.',
      'article_81_case_3': 'Пример: На ден 10.05.2024, работникот не ги следеше техничките упатства за работа со опремата, што беше утврдено од страна на надзорниот орган. Спротивно на упатствата, работникот користеше непрописни алатки.',
      'article_81_case_4': 'Пример: На ден 25.06.2024, работникот се појави на работа во 10:30 часот, наместо задолжителното работно време кое започнува во 08:00 часот. Ова не е прв случај на непочитување на работното време.',
      'article_81_case_5': 'Пример: На ден 12.07.2024, работникот не дојде на работа без претходно да побара отсуство или да го извести работодавачот. Работникот не се јави ни телефонски ниту по електронска пошта.',
      'article_81_case_6': 'Пример: На ден 18.08.2024, работникот отсуствуваше од работа поради болест, но не го извести работодавачот во рок од 48 часа, како што е пропишано со законот. Известувањето беше доставено по 72 часа.',
      'article_81_case_7': 'Пример: На ден 05.09.2024, работникот несовесно постапуваше со средствата за работа, оставајќи ги алатите и опремата изложени на временски услови. Ова доведе до оштетување на опремата во вредност од 15.000 денари.',
      'article_81_case_8': 'Пример: На ден 22.09.2024, работникот предизвика оштетување на опремата, но истото не го пријави веднаш на работодавачот. Штетата беше откриена од друг вработен по 3 дена.',
      'article_81_case_9': 'Пример: На ден 30.10.2024, работникот не ги користеше прописните заштитни средства (каска, заштитни ракавици) при извршување на работни задачи, спротивно на упатствата за заштита при работа.',
      'article_81_case_10': 'Пример: На ден 14.11.2024, работникот предизвика вербална конфронтација со колега, употребувајќи навредливи зборови и закани, што создаде непријатна работна атмосфера. Случајот беше потврден од страна на сведоци.',
      'article_81_case_11': 'Пример: На ден 02.12.2024, работникот ги користеше службените возила за приватни цели без одобрение, што е утврдено преку GPS следење на возилата.',
      'article_82_case_1': 'Пример: Работникот неоправдано отсуствуваше од работа на 10, 11 и 12 јануари 2024 година (три последователни работни дена) без претходно известување и без поднесување на оправдување.',
      'article_82_case_2': 'Пример: На ден 15.02.2024, работникот се појави на јавно место (кафуле) додека официјално беше на боледување, што беше потврдено со фотографии и сведоци.',
      'article_82_case_3': 'Пример: На ден 20.03.2024, работникот не ги почитуваше безбедносните процедури при ракување со опасни материјали, спротивно на прописите за заштита при работа, што создаде ризик за пожар.',
      'article_82_case_4': 'Пример: На ден 05.04.2024, работникот се појави на работа под влијание на алкохол, што беше потврдено со алко-тест и сведоци. Концентрацијата на алкохол беше 0.8 промили.',
      'article_82_case_5': 'Пример: На ден 18.05.2024, работникот изнесе од просториите на компанијата канцелариски материјали (компјутер, принтер) без одобрение, што беше забележано од страна на обезбедувањето.',
      'article_82_case_6': 'Пример: На ден 25.06.2024, работникот ги сподели доверливи деловни информации (ценовници, liste на клиенти) со конкурентска фирма, што беше потврдено преку електронска кореспонденција.'
    };

    return placeholders[articleCase] || 'Опишете ја фактичката ситуација што довела до повредата. Наведете конкретни датуми, настани и околности.';
  };

  // Simplified step content renderer - single step with all fields
  const renderStepContent = ({ currentStepData, formData, errors, handleInputChange, isGenerating }) => {
    const { fields } = terminationDueToFaultConfig;

    // Get selected article case details for display
    const selectedArticleCase = formData.articleCase ?
      ALL_ARTICLE_CASES.find(article => article.value === formData.articleCase) : null;

    // All fields are shown on single step - with dynamic placeholder for factual situation
    const allFields = Object.values(fields).map(field => {
      if (field.name === 'factualSituation') {
        return {
          ...field,
          placeholder: getFactualSituationPlaceholder(formData.articleCase)
        };
      }
      return field;
    });

    return (
      <div className={styles['form-section']}>
        <h3>{currentStepData.title}</h3>
        <p className={styles['section-description']}>{currentStepData.description}</p>

        {/* Legal guidance with link to detailed blog */}
        {currentStepData.legalGuidance && (
          <div className={styles['legal-guidance']}>
            <div className={styles['guidance-header']}>
              <strong>⚖️ Правна насока</strong>
            </div>
            <p className={styles['guidance-text']}>{currentStepData.legalGuidance}</p>
            <div className={styles['info-link']} style={{
              marginTop: '15px',
              padding: '12px',
              backgroundColor: '#e3f2fd',
              borderLeft: '4px solid #2196f3',
              borderRadius: '4px'
            }}>
              <p style={{ margin: 0, fontSize: '14px' }}>
                <strong>📚 Детален водич:</strong> За повеќе информации за членови 81 и 82 од ЗРО,
                <a
                  href="https://nexa.mk/terminal/blogs/5f2b7bea-9c04-4dda-ad2f-997aa050f6dc"
                  target="_blank"
                  rel="noopener noreferrer"
                  style={{
                    marginLeft: '5px',
                    color: '#1976d2',
                    textDecoration: 'underline',
                    fontWeight: 'bold'
                  }}
                >
                  прочитајте го нашиот водич →
                </a>
              </p>
            </div>
          </div>
        )}
        
        {/* Form fields */}
        {allFields.map(field => (
          <FormField
            key={field.name}
            field={field}
            value={formData[field.name]}
            formData={formData}
            onChange={handleInputChange}
            error={errors[field.name]}
            disabled={isGenerating}
          />
        ))}
      </div>
    );
  };

  return (
    <BaseDocumentPage
      config={terminationDueToFaultConfig}
      renderStepContent={renderStepContent}
      title="Одлука за Престанок Поради Вина на Работникот"
      description="Упростена генерација на одлука за престанок врз основа на членови 81 и 82 од ЗРО. Внесувањето во полињата е опционо и не е задолжително - можете да генерирате празен документ за рачно пополнување."
    />
  );
};

export default TerminationDueToFaultPage;