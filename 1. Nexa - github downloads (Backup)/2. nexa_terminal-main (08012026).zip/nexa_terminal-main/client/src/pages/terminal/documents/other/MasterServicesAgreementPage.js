import React from 'react';
import BaseDocumentPage from '../../../../components/documents/BaseDocumentPage';
import FormField, { ConditionalField } from '../../../../components/forms/FormField';
import { masterServicesAgreementConfig, getStepFields } from '../../../../config/documents/masterServicesAgreement';
import styles from '../../../../styles/terminal/documents/DocumentGeneration.module.css';

/**
 * Master Services Agreement Page
 * Uses the reusable base components and configuration-driven approach
 * This page generates professional Master Services agreements in Macedonian
 */
const MasterServicesAgreementPage = () => {

  // Dynamic placeholder examples for service description based on selected service type
  const getServiceDescriptionPlaceholder = (serviceType) => {
    const placeholders = {
      'Консултантски услуги': 'Професионални консултантски услуги во областа на стратешко планирање, процесна оптимизација, имплементација на деловни решенија и менаџмент консултации со фокус на подобрување на деловните перформанси.',
      'ИТ услуги': 'Информатички услуги вклучувајќи развој на софтвер, систем интеграција, техничка поддршка, одржување на серверска инфраструктура, cloud решенија, кибернетичка безбедност и управување со IT проекти.',
      'Маркетинг услуги': 'Комплетни маркетинг услуги вклучувајќи дигитален маркетинг, социјални медиуми, content creation, SEO оптимизација, PPC кампањи, брендинг, истражување на пазар и маркетинг стратегии.',
      'Дизајн услуги': 'Креативни дизајн услуги вклучувајќи графички дизајн, веб дизајн, UI/UX дизајн, индустриски дизајн, амбалажен дизајн, брендинг и визуелна идентичност за печатени и дигитални медиуми.',
      'Правни услуги': 'Правни консултации и претставување вклучувајќи договорно право, корпоративно право, работни односи, интелектуална сопственост, судски постапки и сеопфатни правни советодавни услуги.',
      'Сметководствени услуги': 'Сметководствени и финансиски услуги вклучувајќи книговодство, финансиски извештаи, даночни декларации, ревизија, финансиска анализа, буџетирање и советување за финансиско планирање.',
      'Инженерски услуги': 'Инженерски консултации и услуги вклучувајќи проектирање, технички проценки, надзор на градба, структурни анализи, енергетска ефикасност и технички експертизи.',
      'Образовни услуги': 'Образовни и обучувачки програми вклучувајќи корпоративни тренинзи, професионален развој, специјализирани работилници, онлајн курсеви и сертификациони програми за вработени.',
      'Транспортни услуги': 'Транспортни и логистички услуги вклучувајќи превоз на стока, складирање, дистрибуција, управување со снабдувачки синџир, царински услуги и оптимизација на логистика.',
      'Одржување и сервисирање': 'Услуги на одржување и сервисирање на опрема, машини, возила или објекти вклучувајќи превентивно и коректно одржување, технички прегледи, поправки и редовно сервисирање.',
      'Технички услуги': 'Технички услуги и поддршка вклучувајќи технички консултации, инсталација на системи, калибрација, технички мерења, тестирање и квалитетна контрола на производи и процеси.',
      'Истражување и развој': 'Услуги на истражување и развој вклучувајќи научни истражувања, иновативни проекти, производен развој, тестирање на прототипови, техничка документација и имплементација на нови технологии.',
      'Производни услуги': 'Производни услуги вклучувајќи contract manufacturing, серијско производство, монтажа на производи, контрола на квалитет, пакување и завршна обработка според спецификации на клиентот.',
      'Дистрибуција и логистика': 'Услуги на дистрибуција и логистика вклучувајќи складирање, управување со инвентар, мрежа за дистрибуција, last-mile delivery, оптимизација на транспорт и real-time tracking системи.',
      'Управување со проекти': 'Професионални услуги за управување со проекти вклучувајќи планирање, координација, контрола на буџет, управување со ризици, тимска координација и извештаи за напредок согласно PMI стандарди.',
      'Друго': 'Опишете ги детално услугите кои се предмет на овој рамковен договор - вклучете главни активности, очекувани резултати и начин на извршување.'
    };

    return placeholders[serviceType] || 'Опишете ги услугите со детален опис на активностите, очекуваните резултати и начинот на извршување.';
  };

  /**
   * Custom step content renderer
   * This is the only document-specific logic needed
   */
  const renderStepContent = ({ currentStep, formData, handleInputChange, errors, isGenerating }) => {
    const stepFields = getStepFields(currentStep);
    const stepConfig = masterServicesAgreementConfig.steps.find(s => s.id === currentStep);

    // Custom input change handler to auto-fill serviceDescription when serviceType changes
    const customHandleInputChange = (fieldName, value) => {
      // Call the original handler
      handleInputChange(fieldName, value);

      // If serviceType is being changed, auto-fill serviceDescription with the suggestion
      if (fieldName === 'serviceType' && value) {
        const suggestion = getServiceDescriptionPlaceholder(value);
        // Only set the suggestion if it's not the generic placeholder
        if (suggestion && !suggestion.startsWith('Опишете ги услугите')) {
          handleInputChange('serviceDescription', suggestion);
        }
      }
    };

    // Map fields - serviceDescription no longer needs dynamic placeholder since it will have actual value
    const mappedFields = stepFields.map(field => {
      return field;
    });

    return (
      <div className={styles['form-section']}>
        <h3>{stepConfig.title}</h3>
        {stepConfig.description && <p>{stepConfig.description}</p>}

        {/* Add informational note for step 1 */}
        {currentStep === 1 && (
          <div className={styles['info-box']} style={{
            backgroundColor: '#e3f2fd',
            border: '1px solid #90caf9',
            borderRadius: '6px',
            padding: '12px',
            marginBottom: '20px',
            fontSize: '14px'
          }}>
            <strong>📋 Информации за рамковниот договор:</strong>
            <ul style={{ margin: '8px 0', paddingLeft: '20px' }}>
              <li>Рамковен договор дефинира општи услови за долгорочна соработка</li>
              <li>Конкретни проекти се дефинираат преку посебни SOW (Statement of Work) документи</li>
              <li>Договорот обезбедува флексибилност со фиксирани рамковни услови</li>
            </ul>
          </div>
        )}

        {/* Add informational note for step 3 */}
        {currentStep === 3 && (
          <div className={styles['info-box']} style={{
            backgroundColor: '#fff3cd',
            border: '1px solid #ffeaa7',
            borderRadius: '6px',
            padding: '12px',
            marginBottom: '20px',
            fontSize: '14px'
          }}>
            <strong>💡 Совет за опис на услуги:</strong>
            <ul style={{ margin: '8px 0', paddingLeft: '20px' }}>
              <li>Опишете ги општо услугите кои ќе се вршат во рамките на соработката</li>
              <li>Конкретни детали за секој проект се дефинираат во SOW документи</li>
              <li>Прецизноста на описот помага во избегнување недоразбирања</li>
            </ul>
          </div>
        )}

        {/* Add informational note for step 4 */}
        {currentStep === 4 && (
          <div className={styles['info-box']} style={{
            backgroundColor: '#d1f2eb',
            border: '1px solid #a3e4d7',
            borderRadius: '6px',
            padding: '12px',
            marginBottom: '20px',
            fontSize: '14px'
          }}>
            <strong>💰 Финансиски услови:</strong>
            <ul style={{ margin: '8px 0', paddingLeft: '20px' }}>
              <li>Конкретни цени и износи се дефинираат во посебни SOW документи</li>
              <li>Овде се дефинираат општите услови за плаќање (рокови, начин)</li>
              <li>Стандардниот деловен рок за плаќање е 30 дена според Законот за финансиска дисциплина</li>
            </ul>
          </div>
        )}

        {/* Add informational note for step 6 */}
        {currentStep === 6 && (
          <div className={styles['info-box']} style={{
            backgroundColor: '#f8d7da',
            border: '1px solid #f5c6cb',
            borderRadius: '6px',
            padding: '12px',
            marginBottom: '20px',
            fontSize: '14px'
          }}>
            <strong>⏱️ Времетраење и раскинување:</strong>
            <ul style={{ margin: '8px 0', paddingLeft: '20px' }}>
              <li>Рамковни договори обично се на неопределено време за флексибилност</li>
              <li>Отказниот рок од 30 дена обезбедува доволно време за трансфер на работа</li>
              <li>Активните SOW проекти продолжуваат и по раскинување на рамковниот договор</li>
            </ul>
          </div>
        )}

        {mappedFields.map(field => (
          <React.Fragment key={field.name}>
            {/* Regular fields */}
            {!field.condition && (
              <FormField
                field={field}
                value={formData[field.name]}
                onChange={customHandleInputChange}
                error={errors[field.name]}
                disabled={isGenerating}
                formData={formData}
              />
            )}

            {/* Conditional fields */}
            {field.condition && (
              <ConditionalField condition={field.condition} formData={formData}>
                <FormField
                  field={field}
                  value={formData[field.name]}
                  onChange={customHandleInputChange}
                  error={errors[field.name]}
                  disabled={isGenerating}
                  formData={formData}
                />
              </ConditionalField>
            )}
          </React.Fragment>
        ))}
      </div>
    );
  };

  return (
    <BaseDocumentPage
      config={masterServicesAgreementConfig}
      renderStepContent={renderStepContent}
      title="Рамковен договор за услуги (Master Services Agreement)"
      description="Пополнете ги потребните податоци за генерирање професионален рамковен договор за долгорочна соработка во обезбедување на услуги"
    />
  );
};

export default MasterServicesAgreementPage;
