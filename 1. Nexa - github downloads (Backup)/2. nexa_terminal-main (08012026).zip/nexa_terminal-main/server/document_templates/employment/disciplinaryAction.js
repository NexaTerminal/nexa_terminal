const { Document, Paragraph, TextRun, AlignmentType } = require('docx');
const moment = require('moment');

function generateDisciplinaryActionDoc(formData, user, company) {
  // Company data with defaults
  const companyName = company?.companyName || '[Име на компанија]';
  const companyAddress = company?.companyAddress || company?.address || '[Адреса на компанија]';
  const companyNumber = company?.companyTaxNumber || company?.taxNumber || '[ЕМБС на компанија]';
  const companyManager = company?.companyManager || company?.manager || '[Управител]';
  
  // Employee data
  const employeeName = formData?.employeeName || '[Име на работник]';
  const jobPosition = formData?.jobPosition || '[Работна позиција]';
  
  // Sanction details
  const sanctionDate = formData?.sanctionDate ? moment(formData.sanctionDate).format('DD.MM.YYYY') : moment().format('DD.MM.YYYY');
  const sanctionAmount = formData?.sanctionAmount || '[Висина на казна]';
  const sanctionPeriod = formData?.sanctionPeriod || '[Период]';
  
  // Violation details
  const workTaskFailure = formData?.workTaskFailure || '[Запостави обврска]';
  const employeeWrongDoing = formData?.employeeWrongDoing || '[Постапување спротивно на обврска]';
  const employeeWrongdoingDate = formData?.employeeWrongdoingDate ? moment(formData.employeeWrongdoingDate).format('DD.MM.YYYY') : '[Датум на прекршок]';
  
  const currentDate = moment().format('DD.MM.YYYY');

  const sections = [{
      children: [
        new Paragraph({
          children: [
            new TextRun({ text: `Врз основа на член 84, а во врска со член 81 од Законот за работни односи, работодавачот ${companyName}, со седиште на ${companyAddress}, ЕМБС: ${companyNumber}, претставуван преку Управителот ${companyManager}, на ден ${sanctionDate} година, го донесе следното:` })
          ],
          alignment: AlignmentType.JUSTIFIED,
          spacing: { line: 276 }
        }),
        new Paragraph({ text: '' }),
        new Paragraph({
          children: [
            new TextRun({ text: 'Р Е Ш Е Н И Е', bold: true })
          ],
          alignment: AlignmentType.CENTER,
          spacing: { line: 276 }
        }),
        new Paragraph({
          children: [
            new TextRun({ text: 'за изрекување дисциплинска мерка - парична казна', bold: true })
          ],
          alignment: AlignmentType.CENTER,
          spacing: { line: 276 }
        }),
        new Paragraph({ text: '' }),
        new Paragraph({
          children: [
            new TextRun({ text: `На работникот ${employeeName}, работна позиција ${jobPosition}, му се изрекува дисциплинска мерка - парична казна во висина од ${sanctionAmount}% од нето плата, за период од ${sanctionPeriod} месец/и.` })
          ],
          alignment: AlignmentType.JUSTIFIED,
          spacing: { line: 276 }
        }),
        new Paragraph({ text: '' }),
        new Paragraph({
          children: [
            new TextRun({ text: 'О б р а з л о ж е н и е', bold: true })
          ],
          alignment: AlignmentType.CENTER,
          spacing: { line: 276 }
        }),
        new Paragraph({ text: '' }),
        new Paragraph({
          children: [
            new TextRun({ text: `Работникот ${employeeName}, врз основа на договорот за вработување како и организациската поставеност на процесите и работните задачи кај работодавачот ${companyName}, има работна обврска: ${workTaskFailure}.` })
          ],
          alignment: AlignmentType.JUSTIFIED,
          spacing: { line: 276 }
        }),
        new Paragraph({
          children: [
            new TextRun({ text: `Меѓутоа, на ден ${employeeWrongdoingDate} година, иако работникот ${employeeName} бил запознаен со своите обврски и надлежности, тој постапил спротивно на работната обврска на следниот начин: ${employeeWrongDoing}.` })
          ],
          alignment: AlignmentType.JUSTIFIED,
          spacing: { line: 276 }
        }),
        new Paragraph({
          children: [
            new TextRun({ text: 'Со ваквото постапување, работникот ја повредил работната дисциплина, поради што работодавачот смета дека е оправдано да му се изрече дисциплинска мерка.' })
          ],
          alignment: AlignmentType.JUSTIFIED,
          spacing: { line: 276 }
        }),
        new Paragraph({
          children: [
            new TextRun({ text: 'При одмерување висината на дисциплинската мерка, работодавачот ги зел предвид сите околности на случајот, тежината на повредата и досегашното однесување на работникот.' })
          ],
          alignment: AlignmentType.JUSTIFIED,
          spacing: { line: 276 }
        }),
        new Paragraph({
          children: [
            new TextRun({ text: 'Согласно член 180 од Законот за работни односи, паричната казна не може да биде повисока од 15% од нето платата на работникот и не може да се наплатува подолго од 6 месеци.' })
          ],
          alignment: AlignmentType.JUSTIFIED,
          spacing: { line: 276 }
        }),
        new Paragraph({ text: '' }),
        new Paragraph({
          children: [
            new TextRun({ text: 'Правна поука: Против ова решение работникот има право на приговор во рок од осум дена од денот на приемот на решението.' })
          ],
          alignment: AlignmentType.JUSTIFIED,
          spacing: { line: 276 }
        }),
        new Paragraph({ text: '' }),
        new Paragraph({
          children: [
            new TextRun({ text: 'Доставено до:' })
          ],
          alignment: AlignmentType.LEFT,
          spacing: { line: 276 }
        }),
        new Paragraph({
          children: [
            new TextRun({ text: '- работникот' })
          ],
          alignment: AlignmentType.LEFT,
          spacing: { line: 276 }
        }),
        new Paragraph({
          children: [
            new TextRun({ text: '- личен досие' })
          ],
          alignment: AlignmentType.LEFT,
          spacing: { line: 276 }
        }),
        new Paragraph({
          children: [
            new TextRun({ text: '- архива' })
          ],
          alignment: AlignmentType.LEFT,
          spacing: { line: 276 }
        }),
        new Paragraph({ text: '' }),
        new Paragraph({
          children: [
            new TextRun({ text: `${currentDate} година` })
          ],
          alignment: AlignmentType.LEFT,
          spacing: { line: 276 }
        }),
        new Paragraph({ text: '' }),
        new Paragraph({ text: '' }),
        new Paragraph({
          children: [
            new TextRun({ text: 'За работодавачот' })
          ],
          alignment: AlignmentType.RIGHT,
          spacing: { line: 276 }
        }),
        new Paragraph({
          children: [
            new TextRun({ text: companyName })
          ],
          alignment: AlignmentType.RIGHT,
          spacing: { line: 276 }
        }),
        new Paragraph({
          children: [
            new TextRun({ text: '_____________________' })
          ],
          alignment: AlignmentType.RIGHT,
          spacing: { line: 276 }
        }),
        new Paragraph({
          children: [
            new TextRun({ text: `Управител ${companyManager}` })
          ],
          alignment: AlignmentType.RIGHT
        })
      ]
    }];

  const doc = new Document({ sections });

  return { doc, sections };
}

module.exports = generateDisciplinaryActionDoc;