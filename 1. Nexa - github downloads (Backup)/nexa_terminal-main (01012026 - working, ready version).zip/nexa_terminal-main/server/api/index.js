const app = require('../server.js');

// For Vercel serverless functions
module.exports = app;
